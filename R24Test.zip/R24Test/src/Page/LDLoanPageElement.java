package Page;

import org.testng.annotations.Test;

public class LDLoanPageElement {
  @Test
  public void f() {
  }
}
